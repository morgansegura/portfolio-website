export const site = {
  siteName: "MorganSegura.com",
  seoSiteLabel: " | MorganSegura.com",
};
