import { Figtree } from "next/font/google";

export const fontSans = Figtree({
  variable: "--font-face-sans",
  subsets: ["latin"],
});
